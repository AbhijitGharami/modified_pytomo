audio Package
=============

:mod:`ID3` Module
-----------------

.. automodule:: pytomo.kaa_metadata.audio.ID3
    :members:
    :undoc-members:
    :show-inheritance:

:mod:`ac3` Module
-----------------

.. automodule:: pytomo.kaa_metadata.audio.ac3
    :members:
    :undoc-members:
    :show-inheritance:

:mod:`adts` Module
------------------

.. automodule:: pytomo.kaa_metadata.audio.adts
    :members:
    :undoc-members:
    :show-inheritance:

:mod:`core` Module
------------------

.. automodule:: pytomo.kaa_metadata.audio.core
    :members:
    :undoc-members:
    :show-inheritance:

:mod:`flac` Module
------------------

.. automodule:: pytomo.kaa_metadata.audio.flac
    :members:
    :undoc-members:
    :show-inheritance:

:mod:`m4a` Module
-----------------

.. automodule:: pytomo.kaa_metadata.audio.m4a
    :members:
    :undoc-members:
    :show-inheritance:

:mod:`mp3` Module
-----------------

.. automodule:: pytomo.kaa_metadata.audio.mp3
    :members:
    :undoc-members:
    :show-inheritance:

:mod:`ogg` Module
-----------------

.. automodule:: pytomo.kaa_metadata.audio.ogg
    :members:
    :undoc-members:
    :show-inheritance:

:mod:`pcm` Module
-----------------

.. automodule:: pytomo.kaa_metadata.audio.pcm
    :members:
    :undoc-members:
    :show-inheritance:

:mod:`webradio` Module
----------------------

.. automodule:: pytomo.kaa_metadata.audio.webradio
    :members:
    :undoc-members:
    :show-inheritance:

