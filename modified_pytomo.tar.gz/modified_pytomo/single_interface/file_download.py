#!/usr/bin/env python

import lib_youtube_download
import re
import urllib
import lib_general_download

DOWNLOAD_TIME= 30.0



url='https://www.youtube.com/watch?v=iL3ag-Ych58'
DOWNLOAD_TIME= 30.0
hd_first=False

youtube_ie = lib_youtube_download.get_youtube_info_extractor(DOWNLOAD_TIME)
youtube_ie._hd_first = hd_first
mobj = re.match(youtube_ie._VALID_URL, url)
video_id = mobj.group(2)
video_info = youtube_ie.get_video_info(video_id)
video_token = urllib.unquote_plus(video_info['token'][0])
video_url_list = None
get_video_template = ('http://www.youtube.com/get_video?' + 'video_id=%s&t=%s&eurl=&el=&ps=&asv=&fmt=%%s' % (video_id, video_token))

if('url_encoded_fmt_stream_map' in video_info and len(video_info['url_encoded_fmt_stream_map']) >= 1):
    url_data_strs = video_info['url_encoded_fmt_stream_map'][0].split(',')

url_data = [dict(pairStr.split('=') for pairStr in uds.split('&')) for uds in url_data_strs]

url_map = dict((ud['itag'], urllib.unquote(ud['url'])) for ud in url_data)

if youtube_ie._hd_first:
    format_list = youtube_ie._available_formats_hd_first
else:
    format_list = youtube_ie._available_formats

existing_formats = [x for x in format_list if x in url_map]

video_url_list = [(existing_formats[0],url_map[existing_formats[0]])]

cache_url = video_url_list[0][1]

cache_uri = cache_url


status_code, download_stats, redirect_url = ( lib_general_download.get_download_stats(cache_uri, download_time=DOWNLOAD_TIME))




