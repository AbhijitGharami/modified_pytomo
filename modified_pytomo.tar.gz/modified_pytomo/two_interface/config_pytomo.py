#!/usr/bin/env python

"""The config file for the pytomo setup
Lines starting with # are comments
"""

from logging import DEBUG, INFO, WARNING, ERROR, CRITICAL			#from logging pckg import the values

# use package directory for storing files
# put it False if you want files in the current working dir (from where pytomo
# is launched)
USE_PACKAGE_DIR = False								#default

# execute crawl without prompting user for any parameters
# put to True if you are running jobs automatically
BATCH_MODE = False								#runs in batch mode

#PROVIDER = None								#service provider
PROVIDER = ''

RESULT_DIR = 'results'								#default
RESULT_FILE = None								#default
#RESULT_FILE = 'pytomo.result'

DATABASE_DIR = 'databases'							#default
DATABASE = 'pytomo_database.db'							#default
# DO NOT USE ANY . OR - IN THE TABLE NAME
TABLE = 'pytomo_crawl'								#default

LOG_DIR = 'logs'								#default log directory
# log file use '-' for standard output
LOG_FILE = 'pytomo.log'								#default log file name
#LOG_FILE = '-'

# log level
# choose from: DEBUG, INFO, WARNING, ERROR and CRITICAL
LOG_LEVEL = DEBUG								#default log level

# log the public IP address
LOG_PUBLIC_IP = True								#log public IP

# send the archive with the database and logs to the centralisation server
CENTRALISE_DATA = False								#default centralise data option
CENTRALISATION_SERVER = 'pytomo.dtdns.net'					#centralise server

# loop on input links
LOOP = False									#default loop option
#LOOP = True

# take related links
#RELATED = True
RELATED = False									#default realted value

# Image file to save the graphs
PLOT = False									#default
 # List containig the column names to be plotted
COLUMN_NAMES = ['DownloadBytes', 'MaxInstantThp']				#default
# Choose from  [ PingMin , PingAvg , PingMax , DownloadTime, VideoDuration
# VideoLength, EncodingRate, DownloadBytes, DownloadInterruptions,
# BufferingDuration, PlaybackDuration, BufferDurationAtEnd, MaxInstantThp]

IMAGE_FILE = 'pytomo_image.png'							#default
IMAGE_DIR = 'plots'								#default

# directories used by the graphical interface
RRD_FILE = 'pytomo.rrd'								#default
RRD_DIR = 'rrds'								#default
RRD_PLOT_DIR = 'images'								#default
TEMPLATE_FILE = 'index.html'							#default
TEMPLATES_DIR = 'templates'							#default
DOC_DIR = 'templates/doc/'							#default
PDF_FILE = 'report.pdf'								#default
PDF_DIR = 'pdfs'								#default
# graphical interface default port to run on
WEB_DEFAULT_PORT = '5555'							#default


STD_HEADERS = {									#default
    'Accept-Language': 'en-us,en;q=0.5',
    'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
    'User-Agent': 'Mozilla/5.0 (X11; U; Linux x86_64; en-US; rv:10.0) \
    Gecko/20100101 Firefox/10.0',
    'Accept-Charset': 'ISO-8859-1,utf-8;q=0.7,*;q=0.7',
    'Cookie': 'YSC=h9wy7hcXxIo; VISITOR_INFO1_LIVE=d5TlLfzb2K0; PREF=f1=50000000; s_gl=1d69aac621b2f9c0a25dade722d6e24bcwIAAABVUw=='    
}

STD_HEADERS2 = {									#default
    'Accept-Language': 'en-us,en;q=0.5',
    'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
    'User-Agent': 'Mozilla/5.0 (X11; U; Linux x86_64; en-US; rv:10.0) \
    Gecko/20100101 Firefox/10.0',
    'Accept-Charset': 'ISO-8859-1,utf-8;q=0.7,*;q=0.7',
    'Cookie': 'YSC=h9wy7hcXxIo; VISITOR_INFO1_LIVE=d5TlLfzb2K0; PREF=f1=50000000; s_gl=1d69aac621b2f9c0a25dade722d6e24bcwIAAABVUw=='    
}


################################################################################
# for start_pytomo.py

STATIC_URL_LIST = []								#default
INPUT_FILE = None								#File indicating the URLs to crawl
19820811
# Max number of rounds to perform
MAX_ROUNDS = 10000								#default max round
MAX_CRAWLED_URLS = 10000							#default max crawled url
# Max number of related videos from each url19820811
MAX_PER_URL = 10								#max number of related video
# Max number of related videos from each page
MAX_PER_PAGE = 10								#max number of related video from each page

# timeframe for the most popular videos fetch at start of crawl
# put 'today', 'week', 'month' or 'all_time' (default case)
# new API: only today and all_time are allowed
TIME_FRAME = 'today'								#default time frame
19820811
#Time delay between consecutive url crawls and download requests (in seconds)
DELAY_BETWEEN_REQUESTS = 10							#delay between request
# Max duration of round for getting input links19820811
MAX_ROUND_DURATION = 600							#default

IPADDR_TIMEOUT = 5								#default
URL_TIMEOUT = 5									#defaultf

# choose between 'youtube' and 'dailymotion'
CRAWL_SERVICE = 'youtube'							#default crawl service


################################################################################
# for lib_cache_url.py
# proxy to set at command line
PROXIES = None									#default proxy option
# replace with your values
#PROXIES = {'http': 'http://www.example.com:3128/'}

# cookie file
#cookie_file = 'cookie.jar'

################################################################################
# for lib_dns.py

# other DNS servers to query
GOOGLE_PUBLIC_DNS = ('google_public_dns', '8.8.8.8')				#default
OPEN_DNS = ('open_dns', '208.67.220.220')					#default
# The lifetime of a DNS query(in seconds). The default is 30 seconds.
DNS_TIMEOUT = 4.0								#default
EXTRA_NAME_SERVERS = [GOOGLE_PUBLIC_DNS, OPEN_DNS]				#[('google_public_dns', '8.8.8.8'), ('open_dns', '208.67.220.220')]
#EXTRA_NAME_SERVERS = []
# also download video from IPs resolved by other DNS servers			#for other DNS
DOWNLOAD_FROM_EXTRA_IPS = False							#default

# just for sharing the servers between the modules
EXTRA_NAME_SERVERS_CC = []							#default

# HTTP codes to check for redirects.
HTTP_REDIRECT_MULTIPLE_CHOICES = 300						#default
HTTP_REDIRECT_MOVED_PERMANENTLY = 301						#default
HTTP_REDIRECT_FOUND = 302							#default
HTTP_REDIRECT_SEE_OTHER = 303							#default
HTTP_REDIRECT_NOT_MODIFIED = 304						#default
HTTP_REDIRECT_USE_PROXY = 305							#default
HTTP_REDIRECT_SWITCH_PROXY = 306						#default value
HTTP_REDIRECT_TEMPORARY_REDIRECT = 307						#default
HTTP_REDIRECT_PERMANENT_REDIRECT = 308						#default
#HTTP_REDIRECT_CODE = 302
HTTP_OK = 200									#default
MAX_NB_REDIRECT = 10								#default
HTTP_REDIRECT_CODE_LIST = (							#(300, 301, 302, 303, 304, 305, 306, 307, 308)
    HTTP_REDIRECT_MULTIPLE_CHOICES,	
    HTTP_REDIRECT_MOVED_PERMANENTLY,
    HTTP_REDIRECT_FOUND,
    HTTP_REDIRECT_SEE_OTHER,
    HTTP_REDIRECT_NOT_MODIFIED,
    HTTP_REDIRECT_USE_PROXY,
    HTTP_REDIRECT_SWITCH_PROXY,
    HTTP_REDIRECT_TEMPORARY_REDIRECT,
    HTTP_REDIRECT_PERMANENT_REDIRECT,
)

################################################################################
# for lib_ping.py
# nb of packets to send for ping stats
PING_PACKETS = 10								#no of packet for ping

################################################################################
# for lib_youtube_download.py
DOWNLOAD_TIME = 30.0								#default download time
FREQ_FULL_DOWNLOAD = None							#default
#FREQ_FULL_DOWNLOAD = 40
MAX_DOWNLOAD_TIME = 600.0							#default
INITIAL_BUFFER = 2.0								#default
MIN_PLAYOUT_BUFFER = 0.1							#default
MIN_PLAYOUT_RESTART = 1.0							#default
# Initial playback buffer duration in milliseconds
INITIAL_PLAYBACK_DURATION = 2000						#default

# nb of tries for extracting metadata info from video
MAX_NB_TRIES_ENCODING = 9							#default

# demo mode!
DEMO = False									#default

#EXTRA_COUNTRY = None
# for Tunisia
#EXTRA_COUNTRY = 'TN'
# for France
EXTRA_COUNTRY = 'FR'								#default

#high definition
HD_FIRST = False								#default

################################################################################
# for snmp
SNMP = False 									#default value of SNMP
ROOT_OID = '.1.3.6.1.3.53.5.9'							#default value

# Table of global stats
snmp_pytomoGblStats = '.'.join((ROOT_OID, '1'))					#.1.3.6.1.3.53.5.9.1

snmp_pytomoObjectName = '.'.join((snmp_pytomoGblStats, '1'))			#.1.3.6.1.3.53.5.9.1.1		
snmp_pytomoObjectName_str = 'Pytomo instance'					#default
snmp_pytomoDescr = '.'.join((snmp_pytomoGblStats, '2'))				#.1.3.6.1.3.53.5.9.1.2
snmp_pytomoDescr_str = ('Pytomo  is a YouTube crawler designed to figure out '
                        'network information out of YouTube video download')	#default
snmp_pytomoContact = '.'.join((snmp_pytomoGblStats, '3'))			#.1.3.6.1.3.53.5.9.1.3
snmp_pytomoContact_str = 'Jean-Luc Sire / Pascal Beringuie '			#default
snmp_pytomoDownloadDuration = '.'.join((snmp_pytomoGblStats, '4'))		#.1.3.6.1.3.53.5.9.1.4
snmp_pytomoSleepTime = '.'.join((snmp_pytomoGblStats, '5'))			#.1.3.6.1.3.53.5.9.1.5

# Table of Url stats
snmp_pytomoUrlStats = '.'.join((ROOT_OID, '2', '1', '1'))			#.1.3.6.1.3.53.5.9.2.1.1

# UrlIndex is the first value in the tables but not in the stats!
snmp_pytomoUrlIndex = '.'.join((snmp_pytomoUrlStats, '1'))			#.1.3.6.1.3.53.5.9.2.1.1.1
snmp_pytomoTimeStamp = '.'.join((snmp_pytomoUrlStats, '2'))			#.1.3.6.1.3.53.5.9.2.1.1.2
snmp_pytomoService = '.'.join((snmp_pytomoUrlStats, '3'))			#.1.3.6.1.3.53.5.9.2.1.1.3
snmp_pytomoCacheUrl = '.'.join((snmp_pytomoUrlStats, '4'))			#.1.3.6.1.3.53.5.9.2.1.1.4
snmp_pytomoCacheServerDelay = '.'.join((snmp_pytomoUrlStats, '5'))		#.1.3.6.1.3.53.5.9.2.1.1.5
snmp_pytomoAddressIp = '.'.join((snmp_pytomoUrlStats, '6'))			#.1.3.6.1.3.53.5.9.2.1.1.6
snmp_pytomoResolver = '.'.join((snmp_pytomoUrlStats, '7'))			#.1.3.6.1.3.53.5.9.2.1.1.7
snmp_pytomoResolveTime = '.'.join((snmp_pytomoUrlStats, '8'))			#.1.3.6.1.3.53.5.9.2.1.1.8
snmp_pytomoAsNumber = '.'.join((snmp_pytomoUrlStats, '9'))			#.1.3.6.1.3.53.5.9.2.1.1.9
snmp_pytomoPingMin = '.'.join((snmp_pytomoUrlStats, '10'))			#.1.3.6.1.3.53.5.9.2.1.1.10
snmp_pytomoPingAvg = '.'.join((snmp_pytomoUrlStats, '11'))			#.1.3.6.1.3.53.5.9.2.1.1.11
snmp_pytomoPingMax = '.'.join((snmp_pytomoUrlStats, '12'))			#.1.3.6.1.3.53.5.9.2.1.1.12
snmp_pytomoDownloadTime = '.'.join((snmp_pytomoUrlStats, '13'))			#.1.3.6.1.3.53.5.9.2.1.1.13
snmp_pytomoVideoType = '.'.join((snmp_pytomoUrlStats, '14'))			#.1.3.6.1.3.53.5.9.2.1.1.14
snmp_pytomoVideoDuration = '.'.join((snmp_pytomoUrlStats, '15'))		#.1.3.6.1.3.53.5.9.2.1.1.15
snmp_pytomoVideoLength = '.'.join((snmp_pytomoUrlStats, '16'))			#.1.3.6.1.3.53.5.9.2.1.1.16
snmp_pytomoEncodingRate = '.'.join((snmp_pytomoUrlStats, '17'))			#.1.3.6.1.3.53.5.9.2.1.1.17
snmp_pytomoDownloadBytes = '.'.join((snmp_pytomoUrlStats, '18'))		#.1.3.6.1.3.53.5.9.2.1.1.18
snmp_pytomoDownloadInterruptions = '.'.join((snmp_pytomoUrlStats, '19'))	#.1.3.6.1.3.53.5.9.2.1.1.19
snmp_pytomoInitialData = '.'.join((snmp_pytomoUrlStats, '20'))			#.1.3.6.1.3.53.5.9.2.1.1.20
snmp_pytomoInitialRate = '.'.join((snmp_pytomoUrlStats, '21'))			#.1.3.6.1.3.53.5.9.2.1.1.21
snmp_pytomoInitialPlaybackBuffer = '.'.join((snmp_pytomoUrlStats, '22'))	#.1.3.6.1.3.53.5.9.2.1.1.22
snmp_pytomoBufferingDuration = '.'.join((snmp_pytomoUrlStats, '23'))		#.1.3.6.1.3.53.5.9.2.1.1.23
snmp_pytomoPlaybackDuration = '.'.join((snmp_pytomoUrlStats, '24'))		#.1.3.6.1.3.53.5.9.2.1.1.24
snmp_pytomoBufferDurationAtEnd = '.'.join((snmp_pytomoUrlStats, '25'))		#.1.3.6.1.3.53.5.9.2.1.1.25
snmp_pytomoTimeTogetFirstByte = '.'.join((snmp_pytomoUrlStats, '26'))		#.1.3.6.1.3.53.5.9.2.1.1.26
snmp_pytomoMaxInstantThp = '.'.join((snmp_pytomoUrlStats, '27'))		#.1.3.6.1.3.53.5.9.2.1.1.27
snmp_pytomoRedirectUrl = '.'.join((snmp_pytomoUrlStats, '28'))			#.1.3.6.1.3.53.5.9.2.1.1.28
snmp_pytomoStatusCode = '.'.join((snmp_pytomoUrlStats, '29'))			#.1.3.6.1.3.53.5.9.2.1.1.29

#Statistics by ip 
snmp_pytomoIpStats = '.'.join((ROOT_OID, '3', '1', '1'))			#.1.3.6.1.3.53.5.9.3.1.1
snmp_pytomoIpName = '.' .join((snmp_pytomoIpStats,'1'))				#.1.3.6.1.3.53.5.9.3.1.1.1
snmp_pytomoIpCount = '.' .join((snmp_pytomoIpStats,'2'))			#.1.3.6.1.3.53.5.9.3.1.1.2

#Statistics by AS
snmp_pytomoASStats = '.'.join((ROOT_OID, '4', '1', '1'))			#.1.3.6.1.3.53.5.9.4.1.1
snmp_pytomoASName = '.'.join((snmp_pytomoASStats,'1'))				#.1.3.6.1.3.53.5.9.4.1.1.1
snmp_pytomoASCount = '.'.join((snmp_pytomoASStats,'2'))				#.1.3.6.1.3.53.5.9.4.1.1.2





URL_IDX = 2									#default
TS_IDX = 0									#default
IP_IDX = 5									#default
AS_IDX = 8									#default
STATS_IDX = (				#(2, 0, 1, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 26, 27, 28)
    2, #Url
    0, #TIMESTAMP
    1, #Service
    3, #CacheUrl
    4, #CacheServerDelay
    5, #IP
    6, #Resolver
    7, #ResolveTime
    8, #ASNumber
    9, #PingMin
    10, #PingAvg
    11, #PingMax
    12, #DownloadTime
    13, #VideoType
    14, #VideoDuration
    15, #VideoLength
    16, #EncodingRate
    17, #DownloadBytes
    18, #DownloadInterruptions
    19, #InitialData
    20, #InitialRate
    21, #InitialPlaybackBuffer
    22, #BufferingDuration
    23, #PlaybackDuration
    24, #BufferDurationAtEnd
    25, #TimeTogetFirstByte
    26, #MaxInstantThp
    27, #RedirectUrl
    28, #StatusCode
)

################################################################################
################################################################################
# to be set by start_pytomo.py: DO NOT CHANGE
LOG = None									#default log value
LOG_FILE_TIMESTAMP = None							#default value	later changed
DATABASE_TIMESTAMP = None							#default
TABLE_TIMESTAMP = None								#default
SYSTEM = None									#default
RTT = None									#default
DOWNLOADED_BY_IP = {}								#default
DOWNLOADED_BY_AS = {}								#default


SEP_LINE = 80 * '#'								#print 80 times #
NB_IDENT_VALUES = 8								#default
NB_PING_VALUES = 3								#default
NB_DOWNLOAD_VALUES = 15								#default
NB_RELATED_VALUES = 2								#default
NB_FIELDS = (NB_IDENT_VALUES + NB_PING_VALUES + NB_DOWNLOAD_VALUES		#28
             + NB_RELATED_VALUES)

USER_INPUT_TIMEOUT = 10								#DEFAULT
CRAWLED_URLS_MODULO = 5								#default
	
LEVEL_TO_NAME = {DEBUG: 'DEBUG',						#{40: 'ERROR', 10: 'DEBUG', 20: 'INFO', 50: 'CRITICAL', 30: 'WARNING'}
                 INFO: 'INFO',
                 WARNING: 'WARNING',
                 ERROR: 'ERROR',
                 CRITICAL: 'CRITICAL'}

NAME_TO_LEVEL = {'DEBUG': DEBUG,						#set name to level
                 'INFO': INFO,							#{'DEBUG': 10, 'INFO': 20, 'WARNING': 30, 'CRITICAL': 50, 'ERROR': 40}
                 'WARNING': WARNING,
                 'ERROR': ERROR,
                 'CRITICAL': CRITICAL}						#CRITICAL=50

# set for NOT computing stats on already seen IP addresses
SKIP_COMPUTED = False								#default

################################################################################
# black list utils

BLACK_LISTED = 'das_captcha'							#default

class BlackListException(Exception):						#exception
    "Exception in case the crawler has been blacklisted"
    pass

