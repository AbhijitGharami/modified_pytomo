#!/usr/bin/env python

import sys

import config_pytomo

BUFFERING_STATE = 2

class FileDownloader(object):
    """File Downloader class."""
    params = None
    _ies = []
    #_pps = []
    _download_retcode = None
    _total_bytes = None
    _total_time = None
    _format_downloaded = None

    def __init__(self, download_time):
        self._ies = []
        #self._pps = []
        self._download_retcode = 0
        self._num_downloads = 0
        self._screen_file = sys.stdout
        self.state = BUFFERING_STATE
        self.accumulated_playback = 0.0
        self.accumulated_buffer = 0.0
        self.current_buffer = 0.0
        self.interruptions = 0
        self.current_time = None
        self.start_playback = None
        self.encoding_rate = None
        self.data_len = None
        self.data_duration = None
        self.max_instant_thp = None
        self.video_type = None
        self.redirect_url = None
        self.initial_data = None
        self.initial_rate = None
        self.initial_playback_buffer = None
        self.flv_timestamp = None
        self.previous_timestamp = None
        self.time_to_get_first_byte = None
        try:
            self.download_time = int(download_time)
        except ValueError:
            print "Please provide a number as max download time. Got : %s",download_time
            self.download_time = config_pytomo.DOWNLOAD_TIME
            print 'Set max download_time as: %d' % self.download_time
        if self.download_time <= 0:
            self.download_time = config_pytomo.MAX_DOWNLOAD_TIME
        print 'Max download_time is: %d' % self.download_time

